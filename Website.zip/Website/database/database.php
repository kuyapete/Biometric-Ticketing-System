<?php 
try {
	$conn = new PDO ('mysql:host=localhost;dbname=ams','root','');
 } catch (Exception $e) {
 	die('Error :'.$e->getMessage());
 } ?>