<?php include('../inc/header.php') ?>
<?php include('../inc/nav.inc') ?>

<?php 
    session_start();
    session_regenerate_id();
// !isset($_SESSION['accID']) ? header('Location:../index.php') : '';
    
    include('../../database/database.php');
      $view_events = $conn->query("SELECT * FROM events ORDER BY ID ASC");    
      $view_events->execute();
      $view_events=$view_events->fetchAll(PDO::FETCH_ASSOC);

?>
	
<style>
	.reduce{
		margin-left: 260px;
		right: 0px;
		}	
		 th{
			text-align: center;
			background: #ccc;
			font-family: 'Raleway', sans-serif;
			font-weight: bold;
		}
		td{
			text-align: center;
		}
#imaginary_container{
	width: 25%;
	float: right;
	margin-bottom: 10px;
}
.stylish-input-group .input-group-addon{
    background: white !important; 
}
.stylish-input-group .form-control{
	border-right:0; 
	box-shadow:0 0 0; 
	border-color:#ccc;
}
.stylish-input-group button{
    border:0;
    background:transparent;
}
table a:hover{
	color:#e74c3c;
}
</style>
<div class="reduce panel panel-default">
  <div class="panel-heading">
  <h4>Realtime event logs <span class="fa fa-list"></span></h4>
  </div>
   <div class="panel-body" style="padding:0;border:0px;height:450px;overflow-y:auto; overflow-x:hidden;">
   	<table class="table table-striped table-bordered">
	 <thead>
   		<th>Student ID</th>
   		<th>Event name</th>
   		<th>Time Log </th>
   		</thead>	
      <tbody></tbody>
   	</table>
  </div>
</div>
<?php include('../inc/footer.php') ?>
<!-- modal for info -->


<script type="text/javascript" src="../realtimelogs/autoload.js"></script>