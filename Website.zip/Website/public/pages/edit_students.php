<?php include('../inc/header.php'); ?>
<?php include('../inc/nav.inc'); ?>

<?php 
session_start();
session_regenerate_id();
require('../../database/database.php');

// !isset($_SESSION['accID']) ? header('Location:index.php') : '';



$department = array ('CA - COLLEGE OF AGRICULTURE','CE - COLLEGE OF EDUCATION','CIS - COLLEGE OF INFORMATION SYSTEMS',
  'CAS - COLLEGE OF ARTS AND SCIENCES','IVM - INSTITUTE OF VETERINARY MEDICINE','IAWM - INSTITUE OF AGROFORESTRY AND WATERSHED MANAGEMENT');
$courses = array ('Bachelor of Science in Agribusiness Management','Bachelor of Science in Agricultural Engineering','Bachelor of Science in Agriculture',
  'Bachelor of Elementary Education','Bachelor of Secondary Education',
  'Bachelor of Science in Information Systems',
  'Bachelor of Science in Biology','Bachelor of Arts in English Language',
  'Doctor of Veterinary Medicine',
  'Bachelor of Science in Agroforestry','Bachelor of Science in Forestry');



if(isset($_GET['stud_id'])){
    $fetchData = $conn->prepare("SELECT * FROM students WHERE id = :student_id");
    $fetchData->execute(array(':student_id'=>$_GET['stud_id']));
    $e = $fetchData->fetch(PDO::FETCH_ASSOC);
}

  


if(isset($_POST['update'])){
         foreach($_POST as $e){
        $x[] = $e;

      }
        if($x[8] == 'Bachelor of Science in Agribusiness Management' OR $x[8] =='Bachelor of Science in Agricultural Engineering' OR $x[8] == 'Bachelor of Science in Agriculture'){
              $department = 'CA - COLLEGE OF AGRICULTURE';
        }else if ($x[8] == 'Bachelor of Elementary Education' OR $x[8] == 'Bachelor of Secondary Education'){
              $department = 'CE - COLLEGE OF EDUCATION';
        }else if ($x[8] == 'Bachelor of Science in Information Systems'){
              $department = 'CIS - COLLEGE OF INFORMATION SYSTEMS';
        }else if ($x[8] == 'Bachelor of Science in Biology' OR $x[8] == 'Bachelor of Arts in English Language'){
              $department = 'CAS - COLLEGE OF ARTS AND SCIENCE';
        }else if ($x[8] == 'Doctor of Veterinary Medicine'){
              $department = 'IVM - INSTITUTE OF VETERINARY MEDICINE';
        }else if ($x[8] == 'Bachelor of Science in Agroforestry' OR $x[8] == 'Bachelor of Science in Forestry'){
              $department = 'IAWM - INSTITUE OF AGROFORESTRY AND WATERSHED MANAGEMENT';
        }else {
              $department = 'N/A';
        }
 $update = $conn->query("UPDATE `students` SET `firstname`='$x[0]',`middlename`='$x[1]',`surname`='$x[2]',`contact`='$x[3]',`email`='$x[4]',`address`='$x[5]',`gender`='$x[6]',`course`='$x[8]',`department`='$department',`year`='$x[7]' WHERE id = '".$_GET['stud_id']."'");
 $update->execute();

  if($update){
    echo "<script>alert('Record Updated succesfuly..');
    window.location='home.php';</script>";
  }else{
      echo "<script>alert('Something went wrong');
      window.location='home.php';</script>";
  }
        
}

 ?> 

<div class="reduce panel panel-default">
<div class="panel-heading">
<h4>Student List <span class="fa fa-list"></span></h4>
</div>

  


<form class="form-horizontal" method="POST" action="#">
<fieldset>
  <div class="panel-body" style="padding:0;border:0px;height:500px;overflow-y:auto; overflow-x:hidden;">
  
   <legend style="text-indent: 10%;color:red; margin-top:20px;">Student info :</legend>
    
    <div class="form-group">
      <label class="col-lg-3 control-label">Firstname<span class="text text-danger">:</span></label>
      <div class="col-lg-6 ">
        <input type="text" class="form-control" name="firstname" value="<?=$e['firstname'];?>">
      </div>
    </div>

    <div class="form-group">
      <label class="col-lg-3 control-label">Middlename<span class="text text-danger">:</span></label>
      <div class="col-lg-6 ">
        <input type="text" class="form-control" name="middlename" value="<?=$e['middlename'];?>" >
      </div>
    </div>

    <div class="form-group">
      <label class="col-lg-3 control-label">Surname<span class="text text-danger">:</span></label>
      <div class="col-lg-6 ">
        <input type="text" class="form-control" name="Surname" value="<?=$e['surname'];?>" >
      </div>
    </div>

    <div class="form-group">
      <label class="col-lg-3 control-label">Contact #<span class="text text-danger">:</span></label>
      <div class="col-lg-6 ">
        <input type="text" class="form-control" name="Contact" value="<?=$e['contact'];?>">
      </div>
    </div>

     <div class="form-group">
      <label class="col-lg-3 control-label">Email Address <span class="text text-danger">:</span></label>
      <div class="col-lg-6 ">
        <input type="text" class="form-control" name="Email" value="<?=$e['email'];?>">
      </div>
    </div>

 
    <div class="form-group">
      <label for="textArea" class="col-lg-3 control-label">Address<span class="text text-danger">:</span></label>
      <div class="col-lg-6 ">
        <textarea class="form-control" rows="3" name="Address" value="<?=$e['address'];?>"><?=$e['address'];?></textarea>
      </div>
    </div>

<div class="form-group">
      <label for="select" class="col-lg-3 control-label">Gender <span class="text text-danger">:</span></label>
      <div class="col-lg-2 ">
        <select class="form-control" name="gender">
            <option value="<?=$e['gender'];?>"><?=$e['gender'];?></option>
            <option value="Male">Male</option>
            <option value="FeMale">FeMale</option>
        </select>
    </div>
    <div class="col-lg-2 ">
        <select class="form-control" name="year"  required/>
            <option value="<?=$e['year']?>"><?=$e['year']?></option>
            <option value="First">First</option>
            <option value="Second">Second</option>
            <option value="Third">Third</option>
            <option value="Fourth">Fourth</option>
            <option value="Fifth">Fifth</option>
        </select>
    </div>
  </div>


    <div class="form-group">
      <label for="select" class="col-lg-3 control-label">Course <span class="text text-danger">:</span></label>
      <div class="col-lg-6 ">
        <select class="form-control" name="Course">
            <option value="<?=$e['course'];?>"><?=$e['course'];?></option>
            <?php foreach($courses as $course): ?>
              <option value="<?=$course;?>"><?=$course;?></option>
              <?php endforeach; ?>
        </select>
    </div>
  </div>

    <div class="form-group">
      <label for="textArea" class="col-lg-3 control-label">Address<span class="text text-danger">:</span></label>
      <div class="col-lg-6 ">
        <textarea class="form-control" rows="3"  name="address" value="<?=$e['address'];?>"><?=$e['address'];?></textarea>
      </div>
    </div>
      <div class="form-group">
        <div class="col-lg-6 col-lg-offset-3">
          <input type="submit" name="update" value="Update" class="btn btn-primary">
          <a href="home.php" class="btn btn-primary ">Cancel</a>
        </div>
      </div>
</fieldset>

</form>

</div>



</div>
</div>
<?php include('../inc/footer.php'); ?>