<?php
if(isset($_POST["staff_id"])){

      require_once('../../database/database.php');

      $output = '';  
      
      $query = $conn->prepare("SELECT * FROM admin WHERE id = '".$_POST["staff_id"]."'");  
      $query->execute();
      $getinfo = $query->fetchAll();
      $output .= '  
      <div class="table-responsive">  
           <table class="table table-bordered table-hover">';  
      		foreach($getinfo as $row){
          
                if($row['gender' == 0]){
                  $row['gender'] = 'Female';
                } else {
                  $row['gender']= 'Male';
                }

                if($row['user_level'] == 0){
                  $row['user_level'] = 'Staff';
                }else {
                  $row['user_level'] = 'Administrator';
                }

           $output .= '  
                <tr>  
                     <td width="30%"><label>Name</label></td>  
                     <td width="70%">'.$row["firstname"].'</td>  
                </tr>  
                 <tr>  
                     <td width="30%"><label>Middle name</label></td>  
                     <td width="70%">'.$row["middlename"].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Sur name</label></td>  
                     <td width="70%">'.$row["surname"].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Gender</label></td>  
                     <td width="70%">'.$row["gender"].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Address</label></td>  
                     <td width="70%">'.$row["address"].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Contact #</label></td>  
                     <td width="70%">'.$row["contact"].'</td>  
                </tr>  
                 <tr>  
                     <td width="30%"><label>Account privileges</label></td>  
                     <td width="70%">'.$row["user_level"].'</td>  
                </tr>  
      
           ';  
      }  
      $output .= '  
           </table>  
      </div>  
      ';  
      echo $output;  
 }  
 ?>  