<?php include('../inc/header.php'); ?>
<?php include('../inc/nav.inc'); ?>



<?php 
session_start();
session_regenerate_id();


// !isset($_SESSION['accID']) ? header('Location:index.php') : '';


if(isset($_POST['insert'])){
    require('../../database/database.php');

    foreach($_POST as $e){
        $x[] = $e;
      }

// print_r($x);
// die()


        $haspass = password_hash($x[6],PASSWORD_BCRYPT);

          $add_Staff = $conn->prepare("INSERT INTO `admin`(`firstname`, `middlename`, `surname`, `contact`, `address`, `gender`, `user_level`, `uid`, `pass`)
            VALUES (:firstname,:middlename,:surname,:contact,:address,:gender,:user_level,:uid,:pass)");
          $add_Staff->execute(array(':firstname'   =>$x[0],        
                                    ':middlename'  =>$x[1],          
                                    ':surname'     =>$x[2],      
                                    ':contact'     =>$x[3],      
                                    ':address'     =>$x[4],      
                                    ':gender'      =>$x[7],      
                                    ':user_level'  =>$x[8],          
                                    ':uid'         =>$x[5],  
                                    ':pass'        =>$haspass));
             if($add_Staff){
      echo "<script type='text/javascript'>
                var x = confirm('New Entry has been added to the database. do you want to add another ?');
                    if(x == true){ self.location='add_staff.php';  }
                          else{ self.location='staff_list.php'; }
              </script>"; 
    }else {
      echo "<script>alert('ERROR 404');
      window.location='staff_list.php';</script>";
    }
}     
?>
<div class="reduce panel panel-default">
<div class="panel-heading">
<h4>Add Staff <span class="fa fa-list"></span></h4>
</div>

<form class="form-horizontal" method="POST" action="#">
<fieldset>
  <div class="panel-body" style="padding:0;border:0px;height:450px;overflow-y:auto; overflow-x:hidden;">
   <legend style="text-indent: 10%;color:red; margin-top:50px;">Staff info :</legend>
    
    <div class="form-group">
      <label class="col-lg-3 control-label">Firstname<span class="text text-danger">:</span></label>
      <div class="col-lg-6 ">
        <input type="text" class="form-control" name="firstname" placeholder="Firstname" required />
      </div>
    </div>

    <div class="form-group">
      <label class="col-lg-3 control-label">Middlename<span class="text text-danger">:</span></label>
      <div class="col-lg-6 ">
        <input type="text" class="form-control" name="middlename" placeholder="Middlename" required />
      </div>
    </div>

    <div class="form-group">
      <label class="col-lg-3 control-label">Surname<span class="text text-danger">:</span></label>
      <div class="col-lg-6 ">
        <input type="text" class="form-control" name="Surname" placeholder="Surname" required />
      </div>
    </div>

    <div class="form-group">
      <label class="col-lg-3 control-label">Contact #<span class="text text-danger">:</span></label>
      <div class="col-lg-6 ">
        <input type="text" class="form-control" name="Contact" placeholder="Contact #" required />
      </div>
    </div>
 
    <div class="form-group">
      <label for="textArea" class="col-lg-3 control-label">Address<span class="text text-danger">:</span></label>
      <div class="col-lg-6 ">
        <textarea class="form-control" rows="3" name="Address" placeholder="Address .." required /></textarea>
      </div>
    </div>
        

    <div class="form-group">
      <label class="col-lg-3 control-label">Username <span class="text text-danger">:</span></label>
      <div class="col-lg-6 ">
        <input type="text" class="form-control" name="uid" placeholder="Username" required />
      </div>
    </div>  

    <div class="form-group">
      <label class="col-lg-3 control-label">Password <span class="text text-danger">:</span></label>
      <div class="col-lg-6 ">
        <input type="password" class="form-control" name="pass" placeholder="Your Password Here" required />
      </div>
    </div>   

    <div class="form-group">
      <label for="select" class="col-lg-3 control-label">Gender <span class="text text-danger">:</span></label>
      <div class="col-lg-2 ">
        <select class="form-control" name="gender" required />
            <option value="">Please Select</option>
            <option value="1">Male</option>
            <option value="0">FeMale</option>
        </select>
      </div>

    <label for="select" class="col-lg-2 control-label">User Level <span class="text text-danger">:</span></label>
    <div class="col-lg-2 ">
        <select class="form-control" name="Course" required />
            <option value="">Please Select</option>
            <option value="1">ADMIN</option>
            <option value="0">STAFF</option>
        </select>
    </div>
  </div>
  

    <div class="form-group">
        <div class="col-lg-6 col-lg-offset-3">
          <input type="submit" name="insert" value="Insert" class="btn btn-primary btn-block">
        </div>
      </div>


</fieldset>

</form>

</div>



</div>
</div>
<?php include('../inc/footer.php'); ?>