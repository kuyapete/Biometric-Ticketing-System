<?php include('../inc/header.php') ?>

<?php include('../inc/nav.inc') ?>

<?php 
require_once('../../database/database.php');
$courses = array ('Bachelor of Science in Computer Engineering','Bachelor of Science in Computer Science Specialized in Software Engineering','Bachelor of Science in Accountancy', 'Bachelor of Secondary Education', 'Bachelor of Elementary Education' ,
  'Bachelor of Science in Hospitality Management','Bachelor of Science in Hospitality Management Specialized in Cruiseline Operations',
  'Bachelor of Science in Hospitality Management Specialized in Culinary',
  'Bachelor of Science in Tourism Management','Bachelor of Science in Business Administration',
  'Bachelor of Arts in Psychology');

$event_ids =$conn->query("SELECT * FROM events");
$e_id = $event_ids->fetchAll(PDO::FETCH_ASSOC);

 ?>
<style type="text/css">
	.reduce{
	margin-left: 260px;
	right: 0px;
	}	
</style>

<div class="reduce panel panel-default">
	<div class="panel-heading">
		<h2>Generate Report</h2>
	</div>
	<form class="form-horizontal" method="GET" action="print.php" target="_blank">
	<div class="panel-body" style="padding:0;border:0px;height:350px;overflow-y:auto; overflow-x:hidden;">
    <div class="form-group " style="margin-top:50px;">
      <label class="col-lg-3 control-label">Print Report For<span class="text text-danger">:</span></label>
      <div class="col-lg-4 ">
        <select name="courses" class="form-control" required>
        			<option value="">Please Select</option>
			        	<?php foreach ($courses as $x): ?>
			        			<option value="<?=$x;?>"><?=$x;?></option>
			        	<?php endforeach ?>
        			<option value="All">All Courses</option>
        </select>
      </div>
    </div>
    <div class="form-group " >
       <label class="col-lg-3 control-label">Event<span class="text text-danger">:</span></label>
      <div class="col-lg-2 ">
        <select name="event_title" class="form-control" required>
        			<option value="">Please Select</option>
        	<?php foreach ($e_id as $date): ?>
        			<option value="<?=$date['event_title'];?>"><?=$date['event_title'];?></option>
        	<?php endforeach ?>
        </select>
      </div>
    </div>
 
      <div class="form-group">
        <div class="col-lg-6 col-lg-offset-3">
          <input type="submit" name="Generate" value="Generate" class="btn btn-primary">
          <a href="home.php" class="btn btn-primary ">Cancel</a>
        </div>
      </div>
</div>
</form>
</div>


	<div class="reduce panel-footer"></div>
</div>
<?php include('../inc/footer.php') ?>





