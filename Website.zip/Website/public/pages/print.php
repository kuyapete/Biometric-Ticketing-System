<?php 
require_once('../../database/database.php');
$courses = array ('Bachelor of Science in Computer Engineering','Bachelor of Science in Computer Science Specialized in Software Engineering','Bachelor of Science in Accountancy', 'Bachelor of Secondary Education', 'Bachelor of Elementary Education' ,
  'Bachelor of Science in Hospitality Management','Bachelor of Science in Hospitality Management Specialized in Cruiseline Operations',
  'Bachelor of Science in Hospitality Management Specialized in Culinary',
  'Bachelor of Science in Tourism Management','Bachelor of Science in Business Administration',
  'Bachelor of Arts in Psychology');



if(isset($_GET['Generate'])){
		$course =  $_GET['courses'];
		$event_date= $_GET['event_title'];
}
 ?>







<!DOCTYPE html>

<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Attendance Report</title>
	<link rel="stylesheet" type="text/css" href="../asserts/css/bootstrap.min.css">

<style type="text/css">
h2{
	padding: 0px;
	margin: 0px;
}
th{
	background: #0089cb;
	color:white;
	font-family: 'Comfortaa';
	font-size: 15px;
}
.title{
	background: #2980b9;
	color: #fff;
}
<?php $event_query=$conn->query("SELECT * FROM events WHERE event_title = '$event_date'");

			  $event_query=$event_query->fetchAll(PDO::FETCH_ASSOC); 
			  ?>
			  	
</style>
</head>
<body onload="window.print()">
<div class="container">
	
<center><h2> MSEUFCI Fingerprint Ticketing System <br><small><?=$event_date; ?><br>Total Attendees:<?=$event_query[0]['attendees'];?></small></h2><br>
<table class="table table-bordered ">
<?php
if($_GET['courses'] == 'All'):
 foreach ($courses as $x): ?>
		<th class="text-center" colspan="15"><?=$x; ?></th>
		<tr>
		 <td class="title text-center">ID</td>
		 <td class="title text-center">Student Name</td>
		 <td class="title text-center">Event Date</td>
		 <td class="title text-center">Event Name</td>
		 <td class="title text-center">Year</td>
	     <td class="title text-center">1st log</td>
	     <td class="title text-center">2nd log</td>
	     <td class="title text-center">3rd log</td>
		</tr>
		<?php $query=$conn->query("SELECT id FROM students WHERE course = '$x'");
			  $query=$query->fetchAll(PDO::FETCH_ASSOC); 

				foreach($query as $id):
							$fetch_attendance = $conn->query("select students.*, student_att.* from students students inner join student_att student_att on student_att.stud_id = students.id where students.id = '".$id['id']."' AND event_name ='$event_date'");
							$fetch = $fetch_attendance->fetchAll(PDO::FETCH_ASSOC);

								$sum = $conn->query("SELECT SUM(fines) as TotalFines FROM student_att WHERE stud_id = '".$id['id']."'");
								$sum = $sum->fetch(PDO::FETCH_ASSOC);

	 			 foreach ($fetch as $att_id):
	 			   $att_id['first_time_in'] ==NULL ? $rep1stin ='EMPTY' : $rep1stin = $att_id['first_time_in'];				  
				   $att_id['second_time_in'] ==NULL ? $rep2ndin ='EMPTY' : $rep2ndin = $att_id['second_time_in'];				   
				   $att_id['third_time_in'] ==NULL ? $rep3rdin ='EMPTY' : $rep3rdin = $att_id['third_time_in'];
	 			  ?>
	 				<tr>
						<td class="text-center"><small><?=$att_id['stud_id'];?></small></td>
						<td class="text-center"><small><?=$att_id['firstname'].' '.$att_id['surname'];?></small></td>
						<td class="text-center"><small><?=$att_id['date'];?></small></td>
						<td class="text-center"><small><?=$att_id['event_name'];?></small></td>
						<td class="text-center"><small><?=$att_id['year'];?></small></td>
						<td class="text-center"><small><?=$rep1stin;?></small></td>
				        <td class="text-center"><small><?=$rep2ndin;?></small></td>
				        <td class="text-center"><small><?=$rep3rdin;?></small></td>
					</tr>
	 				<?php endforeach;
	 						 endforeach; ?>
<?php endforeach;
else: ?>
<th class="text-center" colspan="15"><?=$course; ?></th>
		<tr>
		 <td class="title text-center">ID</td>
		 <td class="title text-center">Event Date</td>
		 <td class="title text-center">Firstname</td>
		 <td class="title text-center">Year</td>
	     <td class="title text-center">1st log</td>
	     <td class="title text-center">2nd log</td>
	     <td class="title text-center">3rd log</td>
		</tr>

<?php $query=$conn->query("SELECT id FROM students WHERE course = '$course'");
			  $query=$query->fetchAll(PDO::FETCH_ASSOC); 

				foreach($query as $id):
							$fetch_attendance = $conn->query("select students.*, student_att.* from students students inner join student_att student_att on student_att.stud_id = students.id where students.id = '".$id['id']."' AND event_name ='$event_date'");
							$fetch = $fetch_attendance->fetchAll(PDO::FETCH_ASSOC);

								$sum = $conn->query("SELECT SUM(fines) as TotalFines FROM student_att WHERE stud_id = '".$id['id']."'");
								$sum = $sum->fetch(PDO::FETCH_ASSOC);

	 			 foreach ($fetch as $att_id):
	 			   $att_id['first_time_in'] ==NULL ? $rep1stin ='EMPTY' : $rep1stin = $att_id['first_time_in'];
				   $att_id['second_time_in'] ==NULL ? $rep2ndin ='EMPTY' : $rep2ndin = $att_id['second_time_in'];
				   $att_id['third_time_in'] ==NULL ? $rep3rdin ='EMPTY' : $rep3rdin = $att_id['third_time_in'];
	 			  ?>
	 				<tr>
						<td class="text-center"><?=$att_id['stud_id'];?></td>
						<td class="text-center"><?=$att_id['date'];?></td>
						<td class="text-center"><?=$att_id['firstname'];?></td>
						<td class="text-center"><?=$att_id['year'];?></td>
						<td class="text-center"><?=$rep1stin;?></td>
				        <td class="text-center"><?=$rep2ndin;?></td>
				        <td class="text-center"><?=$rep3rdin;?></td>
				        
					</tr>
	 				<?php endforeach;
	 						 endforeach; ?>

<?php endif; ?>

</table>
</center>
</div>
</body>
</html>


