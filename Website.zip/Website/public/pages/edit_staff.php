<?php include('../inc/header.php'); ?>
<?php include('../inc/nav.inc'); ?>



<?php 
session_start();
session_regenerate_id();
    require('../../database/database.php');

// !isset($_SESSION['accID']) ? header('Location:index.php') : '';


  $checkuser = $conn->query("SELECT user_level FROM admin WHERE id = '".$_SESSION['accID']."'");
  $checkuser->execute();
  $checkuser=$checkuser->fetch(PDO::FETCH_ASSOC);
      if($checkuser['user_level'] == 0){
       echo "<script>alert('You dont have permision to do the following action.');
        window.location='staff_list.php';</script>";
       }


if(isset($_GET['staff_id'])){

    $get_info = $conn->query("SELECT * FROM admin WHERE id = '".$_GET['staff_id']."'");
    $get_info->execute();
    $i = $get_info->fetch(PDO::FETCH_ASSOC);


}


if(isset($_POST['insert'])){

    foreach($_POST as $e){
        $x[] = $e;
      }


          $update_staff = $conn->prepare("UPDATE `admin` SET `firstname`='$x[0]',`middlename`='$x[1]',`surname`='$x[2]',`contact`='$x[3]',`address`='$x[4]',`gender`='$x[5]',`user_level`='$x[6]' WHERE id = '".$_GET['staff_id']."'");
          $update_staff->execute();

             if($update_staff){
      echo "<script>alert('Staff Sucessfuly updated'); window.location='staff_list.php'; </script>";
    }else {
      echo "<script>alert('ERROR 404');
      window.location='staff_list.php';</script>";
    }

}     
?>



<div class="reduce panel panel-default">
<div class="panel-heading">
<h4>Add Staff <span class="fa fa-list"></span></h4>
</div>

<form class="form-horizontal" method="POST" action="#">
<fieldset>
  <div class="panel-body" style="padding:0;border:0px;height:500px;overflow-y:auto; overflow-x:hidden;">


   <legend style="text-indent: 10%;color:red; margin-top:50px;">Staff info :</legend>
    
    <div class="form-group">
      <label class="col-lg-3 control-label">Firstname<span class="text text-danger">:</span></label>
      <div class="col-lg-6 ">
          <input type="text" class="form-control" name="firstname" value="<?=$i['firstname'];?>">
      </div>
    </div>

    <div class="form-group">
      <label class="col-lg-3 control-label">Middlename<span class="text text-danger">:</span></label>
      <div class="col-lg-6 ">
        <input type="text" class="form-control" name="middlename" value="<?=$i['middlename'];?>">
      </div>
    </div>

    <div class="form-group">
      <label class="col-lg-3 control-label">Surname<span class="text text-danger">:</span></label>
      <div class="col-lg-6 ">
        <input type="text" class="form-control" name="Surname" value="<?=$i['surname'];?>" >
      </div>
    </div>

    <div class="form-group">
      <label class="col-lg-3 control-label">Contact #<span class="text text-danger">:</span></label>
      <div class="col-lg-6 ">
        <input type="text" class="form-control" name="Contact" value="<?=$i['contact'];?>">
      </div>
    </div>

     
    <div class="form-group">
      <label for="textArea" class="col-lg-3 control-label">Address<span class="text text-danger">:</span></label>
      <div class="col-lg-6 ">
        <textarea class="form-control" rows="3" name="Address" value="<?=$i['address'];?>"> <?=$i['address'];?></textarea>
      </div>
    </div>
        

    
    <div class="form-group">
      <label for="select" class="col-lg-3 control-label">Gender <span class="text text-danger">:</span></label>
      <div class="col-lg-2 ">
        <select class="form-control" name="gender">
            <option>Please Select</option>
            <option value="1" <?php  if($i['gender'] == 1) {echo 'selected="selected"'; } ?> >Male</option>
            <option value="0" <?php if($i['gender'] == 0) {echo 'selected="selected"'; } ?> >FeMale</option>
        </select>
      </div>

    <label for="select" class="col-lg-2 control-label">User Level <span class="text text-danger">:</span></label>
    <div class="col-lg-2 ">
        <select class="form-control" name="Course">
            <option>Please Select</option>
            <option value="1" <?php if($i['user_level'] == 1) {echo 'selected="selected"'; } ?>>ADMIN</option>
            <option value="0" <?php if($i['user_level'] == 0) {echo 'selected="selected"'; } ?>>STAFF</option>
        </select>
    </div>
  </div>
    <div class="form-group">
        <div class="col-lg-6 col-lg-offset-3">
          <input type="submit" name="insert" value="Update" class="btn btn-primary btn-block">
        </div>
      </div>


</fieldset>

</form>

</div>



</div>
</div>
<?php include('../inc/footer.php'); ?>