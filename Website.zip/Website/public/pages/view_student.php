<?php
if(isset($_POST["stud_id"])){

      require_once('../../database/database.php');

      $output = '';  
      
      $query = $conn->prepare("SELECT * FROM students WHERE id = '".$_POST["stud_id"]."'");  
      $query->execute();
      $getinfo = $query->fetchAll();
      $output .= '  
      <div class="table-responsive">  
           <table class="table table-bordered table-hover">';  
      		foreach($getinfo as $row){
          
           $output .= '  
                <tr>  
                     <td width="30%"><label>Name</label></td>  
                     <td width="70%">'.$row["firstname"].'</td>  
                </tr>  
                 <tr>  
                     <td width="30%"><label>Middle name</label></td>  
                     <td width="70%">'.$row["middlename"].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Surname</label></td>  
                     <td width="70%">'.$row["surname"].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Course</label></td>  
                     <td width="70%">'.$row["course"].'</td>  
                </tr>
                <tr>  
                     <td width="30%"><label>Year</label></td>  
                     <td width="70%">'.$row["year"].'</td>  
                </tr>
                 <tr>  
                     <td width="30%"><label>Department</label></td>  
                     <td width="70%">'.$row["department"].'</td>  
                </tr> 
                <tr>  
                     <td width="30%"><label>Gender</label></td>  
                     <td width="70%">'.$row["gender"].'</td>  
                </tr>  
                 <tr>
                      <td width="30%"><label>Email Address</label</td>
                      <td width="70%">'.$row["email"].'</td>
                </tr>
                <tr>  
                     <td width="30%"><label>Address</label></td>  
                     <td width="70%">'.$row["address"].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Contact #</label></td>  
                     <td width="70%">'.$row["contact"].'</td>  
                </tr>  
      
           ';  
      }  
      $output .= '  
           </table>  
      </div>  
      ';  
      echo $output;  
 }  
 ?>  