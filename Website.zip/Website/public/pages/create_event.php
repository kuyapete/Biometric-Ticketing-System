<?php include('../inc/header.php'); ?>
<?php include('../inc/nav.inc'); ?>



<?php 
session_start();
session_regenerate_id();


// !isset($_SESSION['accID']) ? header('Location:index.php') : '';


if(isset($_POST['insert'])){
    require('../../database/database.php');
         foreach($_POST as $e){
        $x[] = $e;
      }


$check = $conn->prepare("SELECT * FROM `events` WHERE `event_date` = :event_id");
$check ->execute(array(':event_id'=>$x[1]));
$check = $check->fetchAll(PDO::FETCH_ASSOC);
if(count($check)>0){
    echo "<script>alert('Selected day of event already existing to the database, Please select another day or delete the existing event.');
    window.location='create_event.php';</script>";
  }else{
$event_code = rand(9999,9999999);
$num = 0;
$insert_event = $conn->prepare("INSERT INTO `events`(`event_title`, `event_desc`, `event_date`, `event_time`,`event_time1`,`fines`,`log_count`,`event_code`,`attendees`) 
VALUES (:event_title,:event_desc,:event_date,:event_time,:event_time1,:fines,:log_count,:event_code,:attendees)");
$insert_event->execute(array(':event_title'    => ucfirst($x[0]),
                             ':event_desc'     => ucfirst($x[4]),
                             ':event_date'     => ucfirst($x[1]),
                             ':event_time'     => ucfirst($x[2]),
                             ':event_time1'     => ucfirst($x[3]),
                             ':fines'          =>$x[5],
                             ':log_count'      =>$x[6], 
                             ':event_code' =>$event_code,
                             ':attendees' => $num
                                ));
    if($insert_event){
      $id = $conn->lastInsertId();
      $totalfines = ($x[5]*$x[6]);
      $date = $x[1];
      $logs = $x[6];
      $event_Tname = $x[0];

             $getids = $conn->query("SELECT id FROM students");
              $getids->execute();
              $getids = $getids->fetchAll(PDO::FETCH_NUM);
              foreach ($getids as $key => $x) {
               $arrays_of_id[] = $x;
              }
      $countstart = 0;
      for($i=0;$i<=count($arrays_of_id)-1;$i++){
      $arrays_of_id[$i][0];
      $insert_att = $conn->query("INSERT INTO student_att (stud_id,event_id,fines,date,log,event_name) VALUES ('".$arrays_of_id[$i][0]."','$id','$totalfines','$date','$logs','$event_Tname') ");
      $countstart++;
      }
      if($countstart == count($arrays_of_id)){
 echo "<script>alert('Event Successfuly Created.');
  window.location='event_list.php'</script>";
}
    }else{
         echo "<script>alert('Something went wrong');
            window.location='event_list.php'</script>";
    }
} 
}

?>



<div class="reduce panel panel-default">
<div class="panel-heading">
<h4>Creant event <span class="fa fa-list"></span></h4>
</div>

<form class="form-horizontal" method="POST" action="#">
<fieldset>
  <div class="panel-body" style="padding:0;border:0px;height:500px;overflow-y:auto; overflow-x:hidden;">
  
   <legend style="text-indent: 10%;color:red; margin-top:50px;">Event info :</legend>
    
    <div class="form-group">
      <label class="col-lg-3 control-label">Event Title<span class="text text-danger">:</span></label>
      <div class="col-lg-6 ">
        <input type="text" class="form-control" name="event_title" placeholder="Event Title .."  maxlength="50" minlength="5" required autofocus />
      </div>
    </div>

    <div class="form-group">
      <label class="col-lg-3 control-label">Event Date<span class="text text-danger">:</span></label>
      <div class="col-lg-2 ">
        <input type="date" class="form-control" name="event_date"  required/>
      </div>
    </div>

    <div class="form-group">
      <label class="col-lg-3 control-label">From <span class="text text-danger">:</span></label>
      <div class="col-lg-2">
        <select class="form-control" name="event_start" required/>
            <option value="">Hour</option>
            <?php for($i=1;$i<=12;$i++): strlen($i) == 1 ? $i= '0'.$i : $i; ?>
              <option value="<?=$i;?>"><?=$i;?></option>
            <?php endfor; ?>
        </select>
      </div>
      <div class="form-group">
      <label class="col-lg-2 control-label pull-left">To <span class="text text-danger">:</span></label>
      <div class="col-lg-2">
        <select class="form-control" name="event_time1" required />
            <option value="">Hour</option>
            <?php for($i=1;$i<=12;$i++): strlen($i) == 1 ? $i= '0'.$i : $i; ?>
              <option value="<?=$i;?>"><?=$i;?></option>
            <?php endfor; ?>
        </select>
      </div>
    </div>

    <div class="form-group">
      <label for="textArea" class="col-lg-3 control-label">Event Description<span class="text text-danger">:</span></label>
      <div class="col-lg-6 ">
        <textarea class="form-control" rows="3" name="Address" placeholder="Event Description .."  /></textarea>
      </div>
    </div>

    <div class="form-group">
      <label class="col-lg-3 control-label">Event fines<span class="text text-danger">:</span></label>
      <div class="col-lg-2 ">
        <input type="text" class="form-control" name="fines" placeholder="fines" maxlength="3" minlength="1" onkeypress="return isNumber(event)" value=0 required/>
      </div>
       <label class="col-lg-2  control-label">Logs<span class="text text-danger">:</span></label>
      <div class="col-lg-2 ">
        <input type="number" class="form-control" name="log_count"  max="3" min="1" placeholder="Logs" onkeypress="return isNumber(event)" required/>
      </div>
    </div>

      <div class="form-group">
        <div class="col-lg-6 col-lg-offset-3">
          <input type="submit" name="insert" value="Insert" class="btn btn-primary">
        </div>
      </div>

</fieldset>

</form>

</div>


</div>
</div>
<?php include('../inc/footer.php'); ?>

<script>
  function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        // alert('Only Numbers can be input to the field')
        return false;

    }
    return true;
}
</script>