<?php 

require_once('../../database/database.php');
session_start();
session_regenerate_id();
// !isset($_SESSION['accID']) ? header('Location:../index.php') : '';



$deactivate = $conn->query("UPDATE `students` SET `stat`='INACTIVE'");
$deactivate->execute();
if($deactivate){
	header('Location:home.php');
}

 ?>