<?php include('../inc/header.php') ?>

<?php include('../inc/nav.inc') ?>
<?php session_start();
session_regenerate_id();
// !isset($_SESSION['accID']) ? header('Location:../index.php') : '';

  require_once('../../database/database.php');

if(isset($_GET['stud_id'])){
    $views = $conn->prepare("SELECT * FROM student_att WHERE `stud_id` = :stud_id ORDER BY id DESC");
    $views->execute(array(':stud_id'=>$_GET['stud_id']));
    $views = $views->fetchAll(PDO::FETCH_ASSOC);

         $views2 = $conn->prepare("SELECT * FROM students WHERE id = :stud_id");
          $views2->execute(array(':stud_id'=>$_GET['stud_id']));
          $views2 = $views2->fetch(PDO::FETCH_ASSOC);
          $repdept = substr(str_replace('-','',$views2['department']),0,4);
}     


    if(!$views){
      $total = 0;
    }


 ?>


<style>
.reduce{
	margin-left: 260px;
	right: 0px;
	}	
	 th{
		text-align: center;
		background: #ccc;
		font-family: 'Raleway', sans-serif;
		font-weight: bold;
	}
	td{
		text-align: center;
	}
#imaginary_container{
width: 25%;
float: right;
margin-bottom: 10px;
}
.stylish-input-group .input-group-addon{
  background: white !important; 
}
.stylish-input-group .form-control{
border-right:0; 
box-shadow:0 0 0; 
border-color:#ccc;
}
.stylish-input-group button{
  border:0;
  background:transparent;
}
table a:hover{
color:#e74c3c;
}

table a:focus{
color:#e74c3c;
}

h3{
  padding:0;
  margin: 
}
.title{
  background: #2980b9;
  color: #fff;
}

.line {
 font-size: 12px;
padding:0px;
margin: 0px;
}

</style>


<div class="reduce panel panel-default">
  <div class="panel-heading">
  <h4>Student Attendance <span class="fa fa-list"></span></h4>
  </div>
  <div class="panel-body" style="padding:0;border:0px;height:450px;overflow-y:auto; overflow-x:hidden;">
   <div class="col-lg-12">
   <table class="table table-bordered" >
   <th colspan="12">INFO</th>
      <tr class="title">
        <td>Student ID</td>
        <td>Student Name</td>
        <td>Year</td>
        <td width="50%">Course</td>
        <td>Department</td>
      </tr>
    <tr>
      <td><?=$views2['id']?></td>
      <td><?=ucfirst($views2['firstname']).' '.ucfirst($views2['surname'])?></td>
      <td><?=$views2['year']?></td>
      <td><?=$views2['course']?></td>
      <td><?=$repdept?></td>
    </tr>
   </table>
   </div>
   <div class="col-lg-12">
   <table class="table table-bordered table-striped">
   <th colspan="13">Student Event Attendance</th>
   <tr>
     <td class="title " width="">ID</td>
     <td class="title " width="20%">TITLE</td>
     <td class="title " >DATE</td>
     <td class="title " >1st log</td>
     <td class="title " >2nd log</td>
     <td class="title " >3nd log</td>

   </tr>
    
    <?php foreach ($views as $x):
   $totalfines[] = $x['fines'];
   $total =  array_sum($totalfines);

   
   $x['first_time_in'] ==NULL ? $rep1stin ='EMPTY' : $rep1stin = $x['first_time_in'];
   ;
   $x['second_time_in'] ==NULL ? $rep2ndin ='EMPTY' : $rep2ndin = $x['second_time_in'];
   
   $x['third_time_in'] ==NULL ? $rep3rdin ='EMPTY' : $rep3rdin = $x['third_time_in'];
   

  ?>
    <tr>
        <td class="line"><?=$x['event_id'];?></td>
        <td class="line"><?=$x['event_name'];?></td>
        <td class="line"><?=$x['date'];?></td>
        <td class="line"><?=$rep1stin;?></td>
        <td class="line"><?=$rep2ndin;?></td>
        <td class="line"><?=$rep3rdin;?></td>

</tr>
    <?php endforeach; ?>
   </table>
   </div>
</div>
</div>
<!-- modal for info -->
<?php include('../inc/footer.php') ?>

