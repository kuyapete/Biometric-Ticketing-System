
<?php include('../inc/header.php') ?>
<?php include('../inc/nav.inc') ?>
<?php session_start();
session_regenerate_id();
 require_once('../../database/database.php');
// !isset($_SESSION['accID']) ? header('Location:../index.php') : '';

if(isset($_GET['s'])){

    $sql = $conn->prepare ("SELECT * FROM admin WHERE firstname LIKE '%".$_GET['s']."%' ");
    $sql->execute();
    $sql = $sql->fetchAll(PDO::FETCH_ASSOC);
}  

?>

<style>
    .reduce{
        margin-left: 260px;
        right: 0px;
        }   
         th{
            text-align: center;
            background: #ccc;
            font-family: 'Raleway', sans-serif;
            font-weight: bold;
        }
        td{
            text-align: center;
        }
#imaginary_container{
    width: 25%;
    float: right;
    margin-bottom: 10px;
}
.stylish-input-group .input-group-addon{
    background: white !important; 
}
.stylish-input-group .form-control{
    border-right:0; 
    box-shadow:0 0 0; 
    border-color:#ccc;
}
.stylish-input-group button{
    border:0;
    background:transparent;
}
table a:hover{
    color:#e74c3c;
}
table a:focus{
  color:#e74c3c;
}
table a:active{
  color:#e74c3c;
}

</style>


<div class="reduce panel panel-default">
  <div class="panel-heading">
  <h4>Search results <span class="fa fa-list"></span></h4>
  </div>
<div class="panel-body" style="padding:0;border:0px;height:500px;overflow-y:auto; overflow-x:hidden;">
<form method="post" action="search.php">

               </form>
  <div id="result"><!-- search results will posted here --></div>

  
    <table class="table table-striped table-bordered">
        <th>Firstname</th>
        <th>Middlename</th>
        <th>Surname</th>
        <th colspan="3">Action</th>
         <?php foreach($sql as $view):
        ?>
            <tr>
          <td><?=ucfirst($view['firstname']);?></td>
          <td><?=ucfirst($view['middlename']);?></td>
          <td><?=ucfirst($view['surname']);?></td>
            <td>
            <a href="#"  id="<?php echo $view['id']; ?>" class="view_data"/><span class="fa fa-eye"></span></a>
          </td>
           <td>
            <a href="edit_staff.php?staff_id=<?=$view['id'];?>"><span class="fa fa-edit"></span></a></td>
          <td>
            <a href="drop_students.php?staff_id=<?=$view['id'];?>" onclick="return confirm('Do you want to delete this record ?')"><span class="fa fa-trash"></span></a>
          </td>
            </tr>
      <?php endforeach; ?>            
    </table>


  </div>


</div>

    
<!-- modal for info -->



<?php include('../inc/footer.php') ?>

<div id="dataModal" class="modal fade" />  
      <div class="modal-dialog">  
           <div class="modal-content">  
                <div class="modal-header">  
                     <button type="button" class="close" data-dismiss="modal">&times;</button>  
                     <h4 class="modal-title"><strong>Staff Info</strong> <span class="glyphicon glyphicon-info-sign"></span></h4>  
                </div>  
                <div class="modal-body" id="student_details"></div>  
                <div class="modal-footer">  
                     <button type="button" class="btn btn-success" data-dismiss="modal">Close <span class="glyphicon glyphicon-remove"></span></button>  
                </div>  
           </div>  
      </div>  
 </div>   


<script>
  $(document).on('click','.view_data',function(){
    var staff_id = $(this).attr("id");
    if(staff_id !=''){
        $.ajax({
            url:"view_staff.php",
            method:"POST",
            data:{staff_id:staff_id},
            success:function(data){
              $('#student_details').html(data);
              $('#dataModal').modal('show');
            }
              });
                      } 
              });

</script>