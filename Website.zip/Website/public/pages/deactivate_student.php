<?php 

require_once('../../database/database.php');
session_start();
session_regenerate_id();
// !isset($_SESSION['accID']) ? header('Location:../index.php') : '';



  $checkuser = $conn->query("SELECT * FROM admin WHERE id = '".$_SESSION['accID']."'");
  $checkuser->execute();
  $checkuser=$checkuser->fetch(PDO::FETCH_ASSOC);

		if(isset($_GET['stud_id'])){
			$drop = $conn->prepare('DELETE FROM students WHERE id = :student_id');
			$drop->execute(array(':student_id'=>$_GET['stud_id']));

				if($drop){
					header('Location:home.php');
				}

			}
	

		if(isset($_GET['event_id'])){
			$drop = $conn->prepare('DELETE FROM events WHERE id = :event_id');
			$drop->execute(array(':event_id'=>$_GET['event_id']));

				if($drop){
					header('Location:event_list.php');
				}
		}
		if(isset($_GET['staff_id'])){
				$drop = $conn->prepare('DELETE FROM admin WHERE id = :staff_id');
				$drop->execute(array(':staff_id'=>$_GET['staff_id']));

				if($drop){
					header('Location:staff_list.php');
				}

		}
	


 ?>