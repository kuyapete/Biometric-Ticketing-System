<?php include('../inc/header.php'); ?>
<?php include('../inc/nav.inc'); ?>



<?php 
session_start();
session_regenerate_id();


// !isset($_SESSION['accID']) ? header('Location:index.php') : '';

require_once('../../database/database.php');

if(isset($_GET['event_id'])){

        $query = $conn->prepare("SELECT * FROM events WHERE id = :event_id");
        $query->execute(array(':event_id'=>$_GET['event_id']));
        $e = $query->fetch(PDO::FETCH_ASSOC);

}

    if(isset($_POST['update'])){

          foreach($_POST as $b){$x[] = $b;}

        $update = $conn->query("UPDATE `events` SET `event_title`='$x[0]',`event_desc`='$x[4]',`event_date`='$x[1]',`event_time`='$x[2]',`event_time1`='$x[3]',`fines`='$x[5]',`log_count`='$x[6]' WHERE id = '".$_GET['event_id']."' ");
        if( $update->execute()){
              $totalfines = $x[5]*$x[6];
              $query = $conn->query("UPDATE student_att SET fines = '$totalfines',log = '$x[6]',event_name='$x[0]',date='$x[1]' WHERE event_id = '".$_GET['event_id']."'");
                if($query){
              echo "<script>alert('Event Updated Succesfully . ');  
                    window.location='event_list.php';</script>";
                }
          }else {
              echo "<script>alert('ERROR 404 . ');
              window.location='event_list.php';</script>";
          }


    }

?>

<div class="reduce panel panel-default">
<div class="panel-heading">
<h4>Creant event <span class="fa fa-list"></span></h4>
</div>

<form class="form-horizontal" method="POST" action="#">
<fieldset>
  <div class="panel-body" style="padding:0;border:0px;height:500px;overflow-y:auto; overflow-x:hidden;">
  
   <legend style="text-indent: 10%;color:red; margin-top:50px;">Event info :</legend>
    
    <div class="form-group">
      <label class="col-lg-3 control-label">Event Title<span class="text text-danger">:</span></label>
      <div class="col-lg-6 ">
        <input type="text" class="form-control" name="event_title" value="<?=$e['event_title']?>" maxlength="50" minlength="5" />
      </div>
    </div>

    <div class="form-group">
      <label class="col-lg-3 control-label">Event Date<span class="text text-danger">:</span></label>
      <div class="col-lg-2 ">
        <input type="date" class="form-control" name="event_date" value="<?=$e['event_date']?>" />
      </div>
    </div>

    <div class="form-group">
      <label class="col-lg-3 control-label">From <span class="text text-danger">:</span></label>
      <div class="col-lg-2">
        <select class="form-control" name="event_start" />
            <option value="<?=$e['event_time']?>"><?=$e['event_time']?></option>
            <?php for($i=1;$i<=12;$i++): strlen($i) == 1 ? $i= '0'.$i : $i; ?>
              <option value="<?=$i;?>"><?=$i;?></option>
            <?php endfor; ?>
        </select>
      </div>

      <div class="form-group">
      <label class="col-lg-2 control-label pull-left">To <span class="text text-danger">:</span></label>
      <div class="col-lg-2">
        <select class="form-control" name="event_time1" />
            <option value="<?=$e['event_time1']?>"><?=$e['event_time1']?></option>
            <?php for($i=1;$i<=12;$i++): strlen($i) == 1 ? $i= '0'.$i : $i; ?>
              <option value="<?=$i;?>"><?=$i;?></option>
            <?php endfor; ?>
        </select>
      </div>
    </div>

    <div class="form-group">
      <label for="textArea" class="col-lg-3 control-label">Event Description<span class="text text-danger">:</span></label>
      <div class="col-lg-6 ">
        <textarea class="form-control" rows="3" name="Address" value="<?=$e['event_desc']?>" /><?=$e['event_desc']?></textarea>
      </div>
    </div>

    <div class="form-group">      
       <label class="col-lg-2  control-label">Logs<span class="text text-danger">:</span></label>
      <div class="col-lg-2 ">
        <input type="text" class="form-control" name="log_count" value="<?=$e['log_count']?>" />
      </div>
    </div>

      <div class="form-group">
        <div class="col-lg-6 col-lg-offset-3">
          <input type="submit" name="update" value="Update" class="btn btn-primary">
        </div>
      </div>

</fieldset>

</form>

</div>


</div>
</div>
<?php include('../inc/footer.php'); ?>