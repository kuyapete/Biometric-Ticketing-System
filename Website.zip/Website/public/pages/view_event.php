<?php

if(isset($_POST["event_id"])){

      require_once('../../database/database.php');

      $output = '';  
      
      $query = $conn->prepare("SELECT * FROM events WHERE id = '".$_POST["event_id"]."'");  
      $query->execute();
      $getinfo = $query->fetchAll();
      $output .= '  
      <div class="table-responsive">  
           <table class="table table-bordered table-hover">';  
      		foreach($getinfo as $row){
          
           $output .= '  
                <tr>  
                     <td width="30%"><label>Event Title</label></td>  
                     <td width="70%">'.$row["event_title"].'</td>  
                </tr>  
      
                 <tr>  
                     <td width="30%"><label>Event Date</label></td>  
                     <td width="70%">'.$row["event_date"].'</td>  
                </tr> 
                 <tr>  
                     <td width="30%"><label>Event Time</label></td>  
                     <td width="70%">'.$row["event_time"].'-'.$row["event_time1"].' '.$row['event_session'].'</td>  
                </tr> 

                <tr>  
                     <td width="30%"><label>Event Description</label></td>  
                     <td width="70%">'.$row["event_desc"].'</td>  
                </tr>

                 <tr>  
                     <td width="30%"><label>Attendees</label></td>  
                     <td width="70%">'.$row["attendees"].'</td>  
                </tr> 
                <tr>  
                     <td width="30%"><label>Limit Per Student</label></td>  
                     <td width="70%">'.$row["log_count"].'</td>  
                </tr> 


           ';  
      }  
      $output .= '  
           </table>  
      </div>  
      ';  
      echo $output;  
 }  
 ?>  