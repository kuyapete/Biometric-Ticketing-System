<?php include('../inc/header.php'); ?>
<?php include('../inc/nav.inc'); ?>



<?php 
session_start();
session_regenerate_id();


// !isset($_SESSION['accID']) ? header('Location:index.php') : '';



$department = array ('CBA - College of Business and Accountancy',
                      'CCST - College of Computer Studies and Technology',
                      'CITHM - College of International Tourism and Hospitalty Managment',
                      'CTELA - College of Teacher Education and Liberal Arts',
                      'CNA - College of Nursing and Allied Health Sciences');
$courses = array ('Bachelor of Science in Computer Engineering','Bachelor of Science in Computer Science Specialized in Software Engineering','Bachelor of Science in Accountancy', 'Bachelor of Secondary Education', 'Bachelor of Elementary Education' ,
  'Bachelor of Science in Hospitality Management','Bachelor of Science in Hospitality Management Specialized in Cruiseline Operations',
  'Bachelor of Science in Hospitality Management Specialized in Culinary',
  'Bachelor of Science in Tourism Management','Bachelor of Science in Business Administration',
  'Bachelor of Arts in Psychology');


if(isset($_POST['insert'])){
    require('../../database/database.php');

         foreach($_POST as $e){
        $x[] = $e;
      }

// debug for parameters on submitting datas for creating student
// echo "<tt>";
// echo "<pre>";
// print_r($x);
// echo "</tt>";
// echo "</pre>";

// die();


        if($x[8] === 'Bachelor of Science in Computer Engineering' OR $x[8] ==='Bachelor of Science in Computer Science Specialized in Software Engineering'){
              $department = 'CCST - College of Computer Studies and Technology';
        }else if ($x[8] === 'Bachelor of Science in Accountancy' OR $x[8] === 'Bachelor of Science in Business Administration'){
              $department = 'CBA - College of Business and Accountancy';
        }else if ($x[8] === 'Bachelor of Secondary Education' OR $x[8] === 'Bachelor of Elementary Education'){
              $department = 'CTELA - College of Teacher Education and Liberal Arts';
        }else if ($x[8] === 'Bachelor of Arts in Psychology'){
              $department = 'CNA - College of Nursing and Allied Health Sciences';
        }else if($x[8] === 'Bachelor of Science in Hospitality Management' OR $x[8] === 'Bachelor of Science in Hospitality Management Specialized in Cruiseline Operations' OR $x[8] === 
  'Bachelor of Science in Hospitality Management Specialized in Culinary' OR $x[8] === 
  'Bachelor of Science in Tourism Management'){
              $department = 'CITHM - College of International Tourism and Hospitalty Managment';
        }else {
              $department = 'N/A';
        }


$insert = $conn->prepare("INSERT INTO `students`(`firstname`, `middlename`, `surname`, `contact`, `department`,`address`, `course`,`gender`,`email`,`year`,`stat`) 
  VALUES (:firstname,:middlename,:surname,:contact,:department,:address,:course,:gender,:email,:year,:stat)");
$insert->execute(
  array(':firstname'  => ucfirst($x[0]),
        ':middlename' => ucfirst($x[1]),
        ':surname'    => ucfirst($x[2]),
        ':contact'    => ucfirst($x[3]),
        ':department' => $department,
        ':address'    => ucfirst($x[5]),
        ':course'     => ucfirst($x[8]),
        ':gender'     => ucfirst($x[6]),
        ':email'      => ucfirst($x[4]),
        ':year'       => ucfirst($x[7]),
        ':stat'       => 'INACTIVE'));

    if($insert){
      echo "<script type='text/javascript'>
                var x = confirm('New Entry has been added to the database. do you want to add another ?');
                    if(x == true){ self.location='add_students.php';  }
                          else{ self.location='home.php'; }
              </script>"; 
    }else {
      echo "<script>alert('False');</script>";
    }
        
}

 ?> 

<div class="reduce panel panel-default">
<div class="panel-heading">
<h4>Add Student(s) <span class="fa fa-list"></span></h4>
</div>

<form class="form-horizontal" method="POST" action="#">
<fieldset>
  <div class="panel-body" style="padding:0;border:0px;height:500px;overflow-y:auto; overflow-x:hidden;">
  
   <legend style="text-indent: 10%;color:red; margin-top:20px;">Student info :</legend>
    
    <div class="form-group">
      <label class="col-lg-3 control-label">Firstname<span class="text text-danger">:</span></label>
      <div class="col-lg-6 ">
        <input type="text" class="form-control" name="firstname" placeholder="Firstname"   required/>
      </div>
    </div>

    <div class="form-group">
      <label class="col-lg-3 control-label">Middlename<span class="text text-danger">:</span></label>
      <div class="col-lg-6 ">
      <input type="text" class="form-control" name="middlename" placeholder="Middlename"  required/>
      </div>
    </div>

    <div class="form-group">
      <label class="col-lg-3 control-label">Surname<span class="text text-danger">:</span></label>
      <div class="col-lg-6 ">
      <input type="text" class="form-control" name="Surname" placeholder="Surname"  required/>
      </div>
    </div>

    <div class="form-group">
      <label class="col-lg-3 control-label">Contact #<span class="text text-danger">:</span></label>
      <div class="col-lg-6 ">
      <input type="text" class="form-control" name="Contact" placeholder="Contact #"  required/>
      </div>
    </div>

    <div class="form-group">
      <label class="col-lg-3 control-label">Email Address <span class="text text-danger">:</span></label>
      <div class="col-lg-6 ">
      <input type="email" class="form-control" name="Email" placeholder="sample@rocketmail.com"  required/>
      </div>
    </div>
 
    <div class="form-group">
      <label for="textArea" class="col-lg-3 control-label">Address<span class="text text-danger">:</span></label>
      <div class="col-lg-6 ">
      <textarea class="form-control" rows="1" name="Address" placeholder="Address .."  required/> </textarea>
      </div>
    </div>
        
    <div class="form-group">
      <label for="select" class="col-lg-3 control-label">Gender <span class="text text-danger">:</span></label>
      <div class="col-lg-2 ">
        <select class="form-control" name="gender"  required/>
            <option value="">Please Select</option>
            <option value="Male">Male</option>
            <option value="FeMale">FeMale</option>
        </select>
    </div>
    <div class="col-lg-2 ">
        <select class="form-control" name="year"  required/>
            <option value="">Year</option>
            <option value="First">First</option>
            <option value="Second">Second</option>
            <option value="Third">Third</option>
            <option value="Fourth">Fourth</option>
            <option value="Fifth">Fifth</option>
        </select>
    </div>
  </div>

    <div class="form-group">
      <label for="select" class="col-lg-3 control-label">Course <span class="text text-danger">:</span></label>
      <div class="col-lg-6 ">
        <select class="form-control" name="Course"  required/>
            <option value="">Please Select</option>
            <?php foreach($courses as $course): ?>
              <option value="<?=$course;?>"><?=$course;?></option>
              <?php endforeach; ?>
        </select>
    </div>
  </div>
      <div class="form-group">
        <div class="col-lg-6 col-lg-offset-3">
          <input type="submit" name="insert" value="Insert" class="btn btn-primary">
          <a href="home.php" class="btn btn-primary ">Cancel</a>
        </div>
      </div>


</fieldset>

</form>

</div>



</div>
</div>
<?php include('../inc/footer.php'); ?>