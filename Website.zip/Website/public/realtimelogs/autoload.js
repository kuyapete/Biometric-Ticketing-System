$(document).ready(function(){
done();
});
function done(){ 
	setTimeout(function(){update();
		done();
	},200);//this will set the refresh of the page in the background every 10 sec
}
function update(){
	$.getJSON("../realtimelogs/loadfiles.php",function(data){
		$("tbody").empty();
		$.each(data.dailylogs,function (){
			$("tbody").append("<tr><td class='text-center'><a href='search.php?q="+this['stud_id']+"'>"+this['stud_id']+"</a></td><td class='text-center'> "+this['event_id']+"</td><td class='text-center'>"+this['first_time_in']);
		});
	});
}