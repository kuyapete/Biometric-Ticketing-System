<?php 
require '../../database/database.php';

  $filterdate = date('Y-m-d');
  $checkDay = strtoupper(date('l'));//day Checker
		$select = $conn->query("SELECT * from student_att WHERE  `date`='$filterdate' AND first_time_in IS NOT NULL ORDER BY first_time_in ");
		$select = $select->fetchAll(PDO::FETCH_ASSOC);


	$results = array();
	foreach ($select as $key):
		//this will clean the output of timein
			
		array_push($results, array("stud_id"=>$key['stud_id'],
									"event_id"=>$key['event_name'],
									"first_time_in"=>$key['first_time_in']
									));
		endforeach;
		 echo json_encode(array("dailylogs" =>$results));
	
 ?>

