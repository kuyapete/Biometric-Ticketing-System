<?php 
// session_start();
// session_regenerate_id();

// 	if(!empty($_POST['user']) && !empty($_POST['pass'])){
// 	require_once('../database/database.php');
		
// 		$query = $conn->prepare("SELECT * FROM admin WHERE uid = :uid");
// 		$query->execute(array(':uid'=>$_POST['user']));
// 		$check = $query->fetch(PDO::FETCH_ASSOC);
// 		$message='';
// 		$uid = $_POST['user'];
// 		if(count($check)>0 && password_verify($_POST['pass'],$check['pass'])){
// 			$_SESSION['accID'] = $check['id'];
// 			echo "<script>alert('Welcome! $uid ');
// 			window.location='pages/home.php';</script>";
// 		}else{
// 			$message= " Credentials do not match !";
// 		}
// }
//  
// <!DOCTYPE html>
// <html lang="en">
// <head>
// 	<meta charset="UTF-8">
// 	<title>FINGERPRINT TICKETING SYSTEM</title>
// 	<link rel="stylesheet" type="text/css" href="asserts/css/bootstrap.min.css"/>
// 	<link rel="stylesheet" type="text/css" href="asserts/css/font-awesome.min.css">
// 	<link rel="stylesheet" type="text/css" href="asserts/css/style.css">
// 	<link href='asserts/css/fonts.css' rel='stylesheet' type='text/css'>
// 	<link rel="stylesheet" type="text/css" href="asserts/custom.css">
// <style type="text/css">
// 	.panel input[type='text'],input[type='password']{
// 	font-weight: normal;
// 	outline:none;
// 	background-color:rgba(0, 0, 0, 0.4);
// 	color:#fff;
// 	font-family: 'Comfortaa', cursive;
// }
// </style>
// </head>
// <body>
// <div class="page-header">
// 		<h2 style="padding:0px;margin:0px;"><img src="img/logo.png" height="100px" width="100px" style="margin-bottom: -40px;"> MSEUFCI Fingerprint Ticketing System</h2>
// <div class="col-lg-4 col-lg-offset-4">
// 		<form method="POST" action="#">
// 			<div class="login panel">
// 				<div class="panel-heading">
// 					<h2 ><span class="glyphicon glyphicon-lock"></span> LOGIN FORM </h2>
// 					<hr>
// 				</div>
// 				<div class="panel-body">
// 				<div class="form-group">
// 					<input type="text" name="user" placeholder="User ID" class="form-control" required autofocus />
// 				</div>		
// 				<div class="form-group">
// 					<input type="password" name="pass" placeholder="Password .." class="form-control" required/>
// 				</div>		
// 				<div class="form-group">
// 					<button type="submit" name="login" class="btn btn-primary btn-block">LOG IN <span class="glyphicon glyphicon-chevron-right"></span></button>
// 				</div>
// 					<hr>
// 				<?php if(!empty($message)): 
// 					<span class="alert alert-danger col-lg-12"><?=$message;</span>
// 				<?php endif; 
// 				</div>
// 			</div>
// 		</form>	
// </div>
// </body>
// <script type="text/javascript" src="asserts/js/jquery-3.1.1.min.js"></script>
// <script  src="asserts/js/bootstrap.min.js"></script>
// </html>

header('Location:pages/home.php')
?>


