<?php 
require '../dbc.php';
include('../functions/functions.php');

  $filterday = ucfirst(date('l'));
  $filterdate = date('m/Y');
  $checkDay = strtoupper(date('l'));//day Checker
		$select = $dbc->prepare("SELECT * from employee_att WHERE `day` ='$filterday' AND `date`='$filterdate'");
		$select->execute();
		$select = $select->fetchAll(PDO::FETCH_ASSOC);


	$results = array();
	foreach ($select as $key):
		//this will clean the output of timein
			
		array_push($results, array("fk_employee_att"=>$key['fk_employee_att'],
									"timein"=>$key['timein'],
									"timeout"=>$key['timeout'],
									"branch"=>$key['branch']
									));
		endforeach;
		 echo json_encode(array("dailylogs" =>$results));
	
/*this will automatically disable the logs if the 
  time of duty lapse
NOTE : THIS WILL CHECK EVERY 1 sec
*/
//   $time = date('Hi'); //Hi

// if ($time > '1000' ){//10 AM
//   $updateSched = $dbc->query("UPDATE `employee_sched` SET `log_check`=2 WHERE timeout = '10AM' AND schedule = '$checkDay'");
//   $updateSched->execute();
// }
// elseif ($time >'1300'){//1 pm
//   $updateSched = $dbc->query("UPDATE `employee_sched` SET `log_check`=2 WHERE timeout = '1PM' AND schedule = '$checkDay'");
//   $updateSched->execute();
// }
// elseif ($time >'1600'){//1 pm
//   $updateSched = $dbc->query("UPDATE `employee_sched` SET `log_check`=2 WHERE timeout = '4PM' AND schedule = '$checkDay'");
//   $updateSched->execute();
// }
// elseif ($time >'1900'){//4pm
//   $updateSched = $dbc->query("UPDATE `employee_sched` SET `log_check`=2 WHERE timeout = '7PM' AND schedule = '$checkDay'");
//   $updateSched->execute();
// }
// elseif ($time > '2200'){//7pm
//   $updateSched = $dbc->query("UPDATE `employee_sched` SET `log_check`=2 WHERE timeout = '10PM' AND schedule = '$checkDay'");
//   $updateSched->execute();
// }
// else if($time > '0000'  || $time < '0200'){
//   $updateSched = $dbc->query("UPDATE `employee_sched` SET `log_check`= 0 WHERE schedule = '$checkDay'");
//   $updateSched->execute();
// }

 ?>

