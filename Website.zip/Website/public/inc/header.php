<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title >FINGERPRINT TICKETING SYSTEM</title>
	<link rel="stylesheet" type="text/css" href="../asserts/css/bootstrap.min.css"/>
	<link rel="stylesheet" type="text/css" href="../asserts/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="../asserts/css/style.css">
	<link href='../asserts/css/fonts.css' rel='stylesheet' type='text/css'>
</head>
<body>


