﻿Imports MySql.Data.MySqlClient
Imports System.IO
Delegate Sub FunctionCall(ByVal param)
Public Class MainForm
    Dim MySqlConnection As New MySqlConnection("Server=localhost;User id=root;Password=;Database=ams")
    Dim Command As MySqlCommand

    Private Sub VerifyButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VerifyButton.Click
        Dim Verifier As New VerificationForm()
        Verifier.Verify(Template)
        Verifier.ShowDialog()
    End Sub
    Private Sub CloseButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CloseButton.Click
        Close()
    End Sub

    Private Sub OnTemplate(ByVal template)
        Invoke(New FunctionCall(AddressOf _OnTemplate), template)
    End Sub

    Private Sub _OnTemplate(ByVal template)
        Me.Template = template
        VerifyButton.Enabled = (Not template Is Nothing)
    End Sub
    Private Template As DPFP.Template

    Private Sub MainForm_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load

        Try
            MySqlConnection.Open()
            Dim cmd As New MySqlCommand("SELECT * FROM students", MySqlConnection)
            Dim rdr As MySqlDataReader = cmd.ExecuteReader()
            Dim MemStream As IO.MemoryStream
            Dim fpBytes As Byte()
            While rdr.Read()
                fpBytes = rdr("template")
                MemStream = New IO.MemoryStream(fpBytes)
                Dim template As New DPFP.Template(MemStream)
                OnTemplate(template)
            End While
            MySqlConnection.Close()
        Catch ex As Exception

        End Try
        Dim Verifier As New VerificationForm()
        Verifier.Verify(Template)
        Verifier.ShowDialog()
    End Sub


End Class



