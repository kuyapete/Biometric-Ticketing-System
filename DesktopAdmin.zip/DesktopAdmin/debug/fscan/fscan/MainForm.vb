﻿Imports MySql.Data.MySqlClient
Imports System.IO
Delegate Sub FunctionCall(ByVal param)
Public Class MainForm
    Dim con As New MySqlConnection("Server=localhost;User id=root;Password=;Database=ams")
    Private Template As DPFP.Template

    Private Sub SaveButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveButton.Click
        Dim save As New SaveFileDialog()
        Dim CreateCommand As MySqlCommand = con.CreateCommand
        Dim da As New MySqlDataAdapter("SELECT * FROM students where id = '" & TextBox1.Text & "'", con)
        Dim dt As New DataTable

        da.Fill(dt)
        If Not da Is Nothing Then

            If (dt.Rows(0)("template").ToString = "") Then
                Dim fingerprintData As MemoryStream = New MemoryStream
                Template.Serialize(fingerprintData)
                fingerprintData.Position = 0
                Dim br As BinaryReader = New BinaryReader(fingerprintData)
                Dim bytes() As Byte = br.ReadBytes(CType(fingerprintData.Length, Int32))
                con.Open()
                Try
                    CreateCommand.Parameters.AddWithValue("@Pic", bytes)
                    CreateCommand.CommandText = "UPDATE students SET template = @Pic WHERE id = '" & TextBox1.Text & "'"
                    'Runs Query
                    CreateCommand.ExecuteNonQuery()
                    CreateCommand.Dispose()
                    MsgBox("FINGER PRINT SAVE SUCCESSFUL")
                Catch ex As Exception
                    MsgBox(ex.Message)
                End Try
                con.Close()
            Else
                MsgBox("Finger Print Already Enrolled")
            End If
        End If
    End Sub

    Private Sub CloseButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CloseButton.Click
        Close()
    End Sub

    Private Sub OnTemplate(ByVal template)
        Invoke(New FunctionCall(AddressOf _OnTemplate), template)
    End Sub

    Private Sub _OnTemplate(ByVal template)
        Me.Template = template

        SaveButton.Enabled = (Not template Is Nothing)
    End Sub

    Private Sub MainForm_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        Dim Enroller As New EnrollmentForm()
        AddHandler Enroller.OnTemplate, AddressOf OnTemplate
        Enroller.ShowDialog()

        Timer1.Enabled = True
        Label5.Text = Date.Now.ToString("ddddddddddddddddd, MMMMMMMMMMMMMMM dd yyyy")
    End Sub

    Private Sub label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub EnrollButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EnrollButton.Click
        Dim Enroller As New EnrollmentForm()
        AddHandler Enroller.OnTemplate, AddressOf OnTemplate
        Enroller.ShowDialog()
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Label4.Text = TimeOfDay
    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs)

    End Sub
End Class



