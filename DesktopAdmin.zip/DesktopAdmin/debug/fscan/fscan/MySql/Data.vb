﻿Namespace MySql
    Friend Class Data
    End Class
End Namespace
